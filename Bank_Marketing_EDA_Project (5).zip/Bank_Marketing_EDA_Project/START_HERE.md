# Start Here

1. Download `Bank_Marketing_EDA_Deep_Learning.ipynb`.
2. Open Google Colab: https://colab.research.google.com/
3. Select File -> Upload notebook.
4. Open the first configuration cell and enter the student's name and roll number.
5. Run cells from top to bottom. The first data cell downloads the UCI dataset.
6. The notebook makes EDA figures, compares MLP models, evaluates on a holdout test set, calculates feature importance and generates `Bank_Marketing_EDA_Report.docx`.
7. Download the executed notebook and generated report from Colab's Files panel. Open the report in Word/Google Docs, check student details/figures, and export to PDF.
8. Upload the executed notebook, final report PDF, README, requirements, and dataset source to the public GitHub repository.

## Data variant
This project uses the richer `bank-additional-full.csv` file, not `bank-full.csv`. The first standard version has 41,188 rows, 20 predictors plus `y`.
